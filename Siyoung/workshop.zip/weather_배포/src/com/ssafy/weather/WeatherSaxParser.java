package com.ssafy.weather;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class WeatherSaxParser {
	List<WeatherDto> list = new ArrayList<>();

	public List<WeatherDto> getNewsList(String url) {
		list.removeAll(list);
		connectWeather(url);
		return list;
	}

	private List<WeatherDto> connectWeather(String url) {
		SAXParserFactory f = SAXParserFactory.newInstance();
		try {
			SAXParser parser = f.newSAXParser();
			SAXHandler handler = new SAXHandler();
			parser.parse(new URL(url).openConnection().getInputStream(), handler);
			System.out.println("connectWeather");
			return list;
		} catch (Exception e) {
			throw new RuntimeException();
		}
		
	}

	public class SAXHandler extends DefaultHandler {
		private StringBuilder sb;
		private String content;
		WeatherDto w;

		@Override
		public void characters(char[] ch, int start, int length) throws SAXException {
//			super.characters(ch, start, length);
			this.content = new String(ch, start, length);
//			System.out.println("characters");
//			TODO: Override 하세요.
		}

		@Override
		public void endElement(String uri, String localName, String name) throws SAXException {
//			System.out.println("endElement");
//			TODO: Override 하세요.
			if(name.equals("data")) {
				sb.append(w);
				content = null;
			}else if(name.equals("hour")) {
				w.setHour(this.content);
			} else if(name.equals("temp")) {
				w.setTemp(this.content);
			} else if(name.equals("wfKor")) {
				w.setWfKor(this.content);
			} else if(name.equals("wfEn")) {
				w.setWfEn(this.content);
			} else if(name.equals("reh")) {
				w.setReh(this.content);;
			} else if(name.equals("img")) {
				w.setImg(this.content);
			}
		}

		@Override
		public void startDocument() throws SAXException {
			super.startDocument();
			sb = new StringBuilder();
			System.out.println("startDocument");
//			TODO: Override 하세요.
		}
		@Override
		public void endDocument() throws SAXException {

			System.out.println(sb);
			super.endDocument();
		}

		@Override
		public void startElement(String uri, String localName, String name, Attributes attributes) throws SAXException {
//			super.startElement(uri, localName, name, attributes);
			if(name.equals("data")) {
				w = new WeatherDto();
			}
//			TODO: Override 하세요.
		}
	}

}