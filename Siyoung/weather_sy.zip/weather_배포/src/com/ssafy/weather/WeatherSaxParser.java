package com.ssafy.weather;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class WeatherSaxParser {
	List<WeatherDto> list = new ArrayList<>();

	public List<WeatherDto> getNewsList(String url) {
		list.removeAll(list);
		connectWeather(url);
		return list;
	}

	private List<WeatherDto> connectWeather(String url) {
		SAXParserFactory f = SAXParserFactory.newInstance();
		try {
			SAXParser parser = f.newSAXParser();
			SAXHandler handler = new SAXHandler();
			parser.parse(new URL(url).openConnection().getInputStream(), handler);
			System.out.println("connectWeather");
			return list;
		} catch (Exception e) {
			throw new RuntimeException();
		}
		
	}

	public class SAXHandler extends DefaultHandler {
		private StringBuilder sb;
		WeatherDto w;

		@Override
		public void characters(char[] ch, int start, int length) throws SAXException {
//			super.characters(ch, start, length);
			sb = new StringBuilder();
			sb.append(ch, start, length);
//			TODO: Override 하세요.
		}

		@Override
		public void endElement(String uri, String localName, String name) throws SAXException {
//			TODO: Override 하세요.
			System.out.println("endElement");
			if(name.equals("data")) {
				list.add(w);
				w = null;
			}else if(name.equals("hour")) {
				w.setHour(sb.toString().trim());
			} else if(name.equals("temp")) {
				w.setTemp(sb.toString().trim());
			} else if(name.equals("wfKor")) {
				w.setWfKor(sb.toString().trim());
			} else if(name.equals("wfEn")) {
				w.setWfEn(sb.toString().trim());
			} else if(name.equals("reh")) {
				w.setReh(sb.toString().trim());;
			} else if(name.equals("img")) {
				w.setImg(sb.toString().trim());
			}
		}

		@Override
		public void startDocument() throws SAXException {
			System.out.println("startDocument");
			super.startDocument();
//			TODO: Override 하세요.
		}
		@Override
		public void endDocument() throws SAXException {
			System.out.println("endDocument");
			System.out.println(sb);
			super.endDocument();
		}

		@Override
		public void startElement(String uri, String localName, String name, Attributes attributes) throws SAXException {
//			super.startElement(uri, localName, name, attributes);
			System.out.println("startElement");
			if(name.equals("data")) {
				w = new WeatherDto();
			}
//			TODO: Override 하세요.
		}
	}

}